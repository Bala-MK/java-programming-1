import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent implements OnInit {

  constructor() { }

  blood_groups=["--Select--","A+","A-","B+","B-","AB+","AB-","O+","O-"];
  countries=["--Select--","India"];
  states = [ "--Select--","Andhra Pradesh",
                "Arunachal Pradesh",
                "Assam",
                "Bihar",
                "Chhattisgarh",
                "Goa",
                "Gujarat",
                "Haryana",
                "Himachal Pradesh",
                "Jammu and Kashmir",
                "Jharkhand",
                "Karnataka",
                "Kerala",
                "Madhya Pradesh",
                "Maharashtra",
                "Manipur",
                "Meghalaya",
                "Mizoram",
                "Nagaland",
                "Odisha",
                "Punjab",
                "Rajasthan",
                "Sikkim",
                "Tamil Nadu",
                "Telangana",
                "Tripura",
                "Uttarakhand",
                "Uttar Pradesh",
                "West Bengal",
                "Andaman and Nicobar Islands",
                "Chandigarh",
                "Dadra and Nagar Haveli",
                "Daman and Diu",
                "Delhi",
                "Lakshadweep",
                "Puducherry"];
cities=["--Select--" ,'Visakhapatnam','Vijayawada','Guntur', 'Tirupati', 'Ahmedabad', 'Somnath', 'Dwarka', 'Surat', 'Faridabad', 'Gurugram', 'Panipat', 'Ambala', 'Kanpur','Lucknow',
'Gorakhpur','Varanasi', 'Birmingham'];

  ngOnInit(): void {
  }

}
