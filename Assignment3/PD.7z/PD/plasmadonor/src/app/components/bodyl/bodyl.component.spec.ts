import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BodylComponent } from './bodyl.component';

describe('BodylComponent', () => {
  let component: BodylComponent;
  let fixture: ComponentFixture<BodylComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BodylComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BodylComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
