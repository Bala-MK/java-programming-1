import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bodyr',
  templateUrl: './bodyr.component.html',
  styleUrls: ['./bodyr.component.css']
})
export class BodyrComponent implements OnInit {

  constructor() { }

  
  ngOnInit(): void {
  }

}
