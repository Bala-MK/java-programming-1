import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BodyrComponent } from './bodyr.component';

describe('BodyrComponent', () => {
  let component: BodyrComponent;
  let fixture: ComponentFixture<BodyrComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BodyrComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BodyrComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
