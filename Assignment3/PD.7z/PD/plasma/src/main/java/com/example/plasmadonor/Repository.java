package com.example.plasmadonor;

import org.springframework.data.repository.CrudRepository;

public interface Repository extends CrudRepository<User,String> {
}
