package com.example.plasmadonor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlasmadonorApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlasmadonorApplication.class, args);
	}

}
