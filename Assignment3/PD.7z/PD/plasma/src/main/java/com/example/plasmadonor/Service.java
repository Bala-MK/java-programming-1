package com.example.plasmadonor;

import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@org.springframework.stereotype.Service
public class Service {
    @Autowired
    Repository repo;

    public Optional<User> getUser(String blood){
        List<User> u=new ArrayList<>();
        //return repo.findAll().forEach(e->e.getBlood_group().equals(blood)?u.add(e):;);
        return null;
    }

    public void addUser(User user){
        repo.save(user);
    }
}
