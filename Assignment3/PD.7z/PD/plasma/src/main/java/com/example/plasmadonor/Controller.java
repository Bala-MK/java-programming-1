package com.example.plasmadonor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class Controller {

    @Autowired
    private Service service;

    @CrossOrigin
    @RequestMapping("/find/{blood}")
    public Optional<User> getUser(@PathVariable String blood){
        return service.getUser(blood);
    }

    @CrossOrigin
    @RequestMapping(method = RequestMethod.POST,value = "/new")
    public void addUser(@RequestBody User user){
        service.addUser(user);
    }
}
